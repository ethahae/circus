
local BackGround = class("BackGround",function()
    return cc.Node:create()
end)

function BackGround:create()
    BackGround.new()
end

function BackGround:ctor()

end
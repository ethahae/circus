local CircusBall = require("Circus.CirCusBall")
local CircusBallManager = require("Circus.CirCusBallManager")
local CircusChar = require("Circus.CirCusChar")
local CircusScene = class("CircusScene",function()
    return cc.Scene:create()
end)

function CircusScene.create()
    return CircusScene.new()
end


function CircusScene:ctor()
    local char = CircusChar:create()
    local ball1 = CircusBall:create()
    local ball2 = CircusBall:create()
    local bgGrass = cc.Sprite:createWithSpriteFrameName("circus/grass.png")
    bgGrass:setScale(2.3)
    bgGrass:setAnchorPoint(cc.p(0.0, 0.))
    self:addChild(bgGrass)
    self:addChild(char,1)
    self:addChild(ball1)
    self:addChild(ball2)
    char:attach(ball1)
    ball2:enterStage()
    self.char = char
end

function CircusScene:reset()
    self.char:reset()
    CircusBallManager:reset()
    self.char:attach(CircusBallManager.balls[1])
    CircusBallManager.balls[2]:enterStage()
end


return CircusScene
